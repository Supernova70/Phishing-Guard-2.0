import { useState } from 'react';
import { Outlet, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { WifiOff } from 'lucide-react';
import { Sidebar } from './Sidebar';
import { Header } from './Header';
import { ToastContainer } from '../ui/Toast';
import { useToast } from '../../hooks/useToast';
import { useSystemHealth } from '../../hooks/useSystemHealth';

const PAGE_CONFIG: Record<string, { title: string; breadcrumbs: Array<{ label: string }> }> = {
  '/': { title: 'Dashboard', breadcrumbs: [{ label: 'Monitor' }, { label: 'Dashboard' }] },
  '/emails': { title: 'Email Inbox', breadcrumbs: [{ label: 'Monitor' }, { label: 'Email Inbox' }] },
  '/active-scans': { title: 'Active Scans', breadcrumbs: [{ label: 'Monitor' }, { label: 'Active Scans' }] },
  '/scans': { title: 'Scan Results', breadcrumbs: [{ label: 'Analyze' }, { label: 'Scan Results' }] },
  '/url-analysis': { title: 'URL Analysis', breadcrumbs: [{ label: 'Analyze' }, { label: 'URL Analysis' }] },
  '/attachments': { title: 'Attachments', breadcrumbs: [{ label: 'Analyze' }, { label: 'Attachments' }] },
  '/graph': { title: 'Attribution Graph', breadcrumbs: [{ label: 'Analyze' }, { label: 'Attribution Graph' }] },
  '/campaigns': { title: 'Campaigns', breadcrumbs: [{ label: 'Analyze' }, { label: 'Campaigns' }] },
  '/alerts': { title: 'Alerts', breadcrumbs: [{ label: 'Monitor' }, { label: 'Alerts' }] },
  '/system-health': { title: 'API Health', breadcrumbs: [{ label: 'System' }, { label: 'API Health' }] },
  '/settings': { title: 'Settings', breadcrumbs: [{ label: 'System' }, { label: 'Settings' }] },
  '/users': { title: 'User Management', breadcrumbs: [{ label: 'System' }, { label: 'User Management' }] },
};

// Dynamic route titles (matchers run before the prefix lookup)
const DYNAMIC_TITLES: Array<{ test: RegExp; title: string; crumbs: Array<{ label: string }> }> = [
  {
    test: /^\/scans\/\d+\/report$/,
    title: 'Forensic Report',
    crumbs: [{ label: 'Analyze' }, { label: 'Scan Results' }, { label: 'Forensic Report' }],
  },
  {
    test: /^\/emails\/\d+\/trace$/,
    title: 'Origin Trace',
    crumbs: [{ label: 'Monitor' }, { label: 'Email Inbox' }, { label: 'Origin Trace' }],
  },
  {
    test: /^\/campaigns\/\d+$/,
    title: 'Campaign Detail',
    crumbs: [{ label: 'Analyze' }, { label: 'Campaigns' }, { label: 'Detail' }],
  },
];

export function Layout() {
  const location = useLocation();
  const { health, loading: healthLoading } = useSystemHealth();
  const backendOnline = healthLoading ? null : health !== null;
  const [refreshKey, setRefreshKey] = useState(0);
  const { toasts, toast, removeToast } = useToast();

  // Find current page config (handle dynamic routes like /scans/:id/report)
  const dynamic = DYNAMIC_TITLES.find((d) => d.test.test(location.pathname));
  const pathKey = Object.keys(PAGE_CONFIG).find(
    (k) => location.pathname === k || (k !== '/' && location.pathname.startsWith(k + '/'))
  ) ?? '/';
  const pageConf = dynamic
    ? { title: dynamic.title, breadcrumbs: dynamic.crumbs }
    : PAGE_CONFIG[pathKey] ?? PAGE_CONFIG['/'];

  const handleEmailsFetched = () => setRefreshKey((k) => k + 1);

  return (
    <div className="app-layout" style={{ display: 'flex', height: '100vh', overflow: 'hidden', background: 'var(--bg-page)' }}>
      <Sidebar
        apiStatus={backendOnline === false ? 'offline' : backendOnline ? 'online' : 'warning'}
        health={health}
      />

      <div className="app-column" style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
        {/* Backend Offline Banner */}
        <AnimatePresence>
          {backendOnline === false && (
            <motion.div
              className="app-banner no-print"
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 36, opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              style={{
                background: 'var(--danger-subtle)',
                borderBottom: '1px solid var(--danger)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: 8,
                overflow: 'hidden',
              }}
            >
              <WifiOff size={14} style={{ color: 'var(--danger)' }} />
              <span style={{ fontSize: '0.8rem', color: 'var(--text-danger)', fontWeight: 600 }}>
                Backend Offline — API is not responding
              </span>
            </motion.div>
          )}
        </AnimatePresence>

        <Header
          title={pageConf.title}
          breadcrumbs={pageConf.breadcrumbs}
          onEmailsFetched={handleEmailsFetched}
          toast={toast.success}
          toastError={toast.error}
        />

        <main className="app-main" style={{ flex: 1, overflow: 'auto', background: 'var(--bg-page)' }}>
          <AnimatePresence mode="wait">
            <motion.div
              className="app-page"
              key={location.pathname}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -10 }}
              transition={{ duration: 0.2, ease: 'easeOut' }}
              style={{ height: '100%' }}
            >
              <Outlet context={{ refreshKey, toast }} />
            </motion.div>
          </AnimatePresence>
        </main>
      </div>

      <ToastContainer toasts={toasts} removeToast={removeToast} />
    </div>
  );
}
